typedef struct Nofila {
	int dado;
    struct Nofila *prox;
}No;

typedef struct lista {
	No* inicio;
    No* fim;
    int tamanho_fila;
}TFilaEncCab;

void criar_fila( TFilaEncCab * fila );
int enfileirar( TFilaEncCab *fila, int elemento );
void imprimir( TFilaEncCab fila );
No* aloca( void );
int fila_vazia( TFilaEncCab fila );
int elemento_da_frente( TFilaEncCab fila, int *valor );
int emfileirar_grupo( TFilaEncCab* fila, int vetor[]);
void clonar(TFilaEncCab *fila,TFilaEncCab *fila_clone);