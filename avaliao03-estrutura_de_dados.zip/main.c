#include <stdio.h>
#include <stdlib.h>
#include "estrutura.c"

int main(){
	TFilaEncCab fila;
	TFilaEncCab fila_clonada;
	int vetor[7] = {3,5,7,12,17,2,50};
	int frente;

criar_fila( &fila );
criar_fila(&fila_clonada);

if( fila_vazia(fila ) ) printf( "\nA fila está vazia!\n" );

emfileirar_grupo( &fila, vetor);

elemento_da_frente( fila, &frente );
printf( "\nElemento da frente: %d", frente  );

imprimir(fila);
printf("\n");

clonar(&fila,&fila_clonada);

imprimir(fila_clonada);
printf("\n");

return 0;
}