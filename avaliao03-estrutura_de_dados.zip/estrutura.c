#include "ass.h"

void criar_fila( TFilaEncCab * fila ){
	fila -> inicio = fila -> fim = NULL;
    fila -> tamanho_fila = 0;
}

No* aloca( void ){ return ( (No*) malloc( sizeof(No) ) ); }

int enfileirar( TFilaEncCab *fila, int elemento ){
    No* novo;
	if ( (novo = aloca()) == NULL ) return 0;

    novo -> dado = elemento;
    novo -> prox = NULL;

    if( fila_vazia(*fila) ) fila -> inicio = novo;
    else (fila -> fim) -> prox = novo;

    fila -> fim = novo;
    (fila -> tamanho_fila) ++;
 	return 1;
}

void imprimir( TFilaEncCab fila ){
	printf("\nFila = [ ");
   	for (  ; fila.inicio != NULL; fila.inicio = (fila.inicio)->prox )
		printf( "%d ", (fila.inicio) -> dado );
   	printf("]\n");
}

int fila_vazia( TFilaEncCab fila ){
	return ( fila.inicio == NULL && fila.fim == NULL );
}

int elemento_da_frente( TFilaEncCab fila, int *valor ){
    if ( fila_vazia( fila ) ) return 0;
    *valor = (fila.inicio) -> dado;
    return 1;
}

int emfileirar_grupo( TFilaEncCab* fila, int vetor[]){
	int x;
	if(vetor != NULL){
		for(x=0; x<7; x++){
			enfileirar( fila, vetor[x]);
		}
		return 1;
	}
	else(vetor == NULL);{
		printf("ERRO!");
		return 0;
	}
}
void clonar(TFilaEncCab *fila,TFilaEncCab *fila_clone){
	if(fila -> inicio == NULL){
		printf("A fila está vazia!");
	}
	else{
		No *aux =fila -> inicio;
		while(aux != NULL){
			enfileirar(fila_clone,aux -> dado);
			aux = aux -> prox;
		}
		printf("A fila está clonada!\n");
	}
}