#include <stdio.h>
#include <stdlib.h>
#include "assinatura.h"
#include "funcao.c"


int main(){ 

Vet *lista = NULL;

lista_vazia(lista);
verif_lista_vazia(lista);
lista = inserir_vetor_no_inicio(lista,10);
lista = inserir_vetor_no_inicio(lista,20);
lista = inserir_vetor_no_fim(lista,5);
lista = inserir_vetor_no_fim(lista,7);
lista = inserir_vetor_no_fim(lista,12);
imprimir_lista(lista);
tamanho_lista(lista);
    
return 0;  
}