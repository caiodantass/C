struct vetor{
    int num;
    struct vetor *ap_prox;
};

typedef struct vetor Vet;

Vet* criar_vetor();

int lista_vazia(Vet *lista);

int verif_lista_vazia(Vet *lista);

Vet* inserir_vetor_no_inicio(Vet* lista,int dado);

Vet* inserir_vetor_no_fim(Vet* lista, int dado);

int tamanho_lista(Vet* lista);

void imprimir_lista(Vet* lista);