Vet* criar_vetor(){
    Vet *novo = malloc(sizeof(Vet));
    return novo;
}

int lista_vazia(Vet *lista){ 
    lista = NULL; }

int verif_lista_vazia(Vet *lista){
    if(lista == NULL){
    printf("A lista está vazia\n");
} 
}

Vet* inserir_vetor_no_inicio(Vet* lista,int dado){
    Vet *novo_vetor = criar_vetor();
    novo_vetor -> num = dado;

    if(lista == NULL){
        lista = novo_vetor;
        novo_vetor -> ap_prox = NULL;
    }
    
    else{
        novo_vetor -> ap_prox = lista;
        lista = novo_vetor;
    }
    return lista;
}

Vet* inserir_vetor_no_fim(Vet* lista, int dado){
    Vet* novo_vetor = criar_vetor();
    novo_vetor -> num = dado;

if(lista == NULL){
    novo_vetor -> ap_prox = NULL;
    lista = novo_vetor;
}

else{
    Vet* aux = lista;
    while(aux -> ap_prox != NULL){
        aux = aux -> ap_prox;
    }
    novo_vetor -> ap_prox = NULL;
    aux -> ap_prox = novo_vetor;
}
return lista;
}


int tamanho_lista(Vet* lista){
    int tamanho = 0;
    while( lista != NULL){
        lista = lista -> ap_prox;
        tamanho ++;
        
        
    }
    printf("O tamanho da lista eh: %d\n",tamanho);
    return tamanho;
}

void imprimir_lista(Vet* lista){
    Vet *aux = lista;

while (aux != NULL){
    printf("%d \n",aux -> num);
    aux = aux -> ap_prox;
}
}